﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
 
            Person newPerson = new Person("Koko", 20);
            Console.WriteLine($"{newPerson.Age} {newPerson.Name}");
        }
    }
}
