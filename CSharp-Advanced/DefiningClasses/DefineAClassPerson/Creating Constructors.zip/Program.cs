﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Person person = new Person("Ken", 25);

            Console.WriteLine($"{ person.Name} {person.Age }");
           
        }
    }
}
